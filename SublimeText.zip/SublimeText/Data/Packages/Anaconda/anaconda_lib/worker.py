
# Copyright (C) 2013 - Oscar Campos <oscar.campos@member.fsf.org>
# This program is Free Software see LICENSE file for details

"""Maintain this just for compatibility
"""

from .workers.market import Market as Worker
#  from .store import WorkerStore as Worker

__all__ = ['Worker']
